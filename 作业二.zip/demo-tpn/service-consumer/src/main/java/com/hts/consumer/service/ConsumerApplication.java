package com.hts.consumer.service;

import com.hts.consumer.service.bean.ConsumerComponent;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.swing.plaf.synth.SynthOptionPaneUI;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
public class ConsumerApplication {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProviderConfiguration.class);
        context.start();
        System.out.println("消费者 启动成功");
        ConsumerComponent service = context.getBean(ConsumerComponent.class);
        while (true) {
            service.methodA();
            service.methodB();
            service.methodC();

            // 主要用于每5秒钟发送一次进行统计
            long result = System.currentTimeMillis() & 5000;
            if (result == 0) {
                service.methodTest();
            }
        }
    }

    @Configuration
    @PropertySource("classpath:/dubbo-consumer.properties")
    @ComponentScan("com.hts.consumer.service")
    @EnableDubbo
    static class ProviderConfiguration {
//        @Bean
//        public RegistryConfig registryConfig() {
//            RegistryConfig registryConfig = new RegistryConfig();
//            registryConfig.setAddress("zookeeper://127.0.0.1:2181");
//            return registryConfig;
//        }
    }
}
