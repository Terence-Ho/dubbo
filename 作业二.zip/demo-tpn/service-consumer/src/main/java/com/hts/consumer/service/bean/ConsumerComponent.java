package com.hts.consumer.service.bean;

import com.hts.service.api.service.HelloService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Component;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Component
public class ConsumerComponent {

    @Reference
    private HelloService helloService;

    public void methodA(){
        helloService.methodA();
    }

    public void methodB(){
        helloService.methodB();
    }


    public void methodC(){
        helloService.methodC();
    }

    public void methodTest(){
        helloService.methodTest();
    }
}
