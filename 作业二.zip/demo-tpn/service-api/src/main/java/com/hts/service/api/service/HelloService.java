package com.hts.service.api.service;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
public interface HelloService {


    void methodA();

    void methodB();

    void methodC();

    void methodTest();
}
