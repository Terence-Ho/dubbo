package com.hts.bean;

import java.io.Serializable;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
public class MethodInfo implements Serializable {
    private static final long serialVersionUID = -4135571858031622521L;

    private String name;
    private Long takeTime;
    private Long currentTime;


    public MethodInfo(String name, Long takeTime, Long currentTime) {
        this.name = name;
        this.takeTime = takeTime;
        this.currentTime = currentTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTakeTime() {
        return takeTime;
    }

    public void setTakeTime(Long takeTime) {
        this.takeTime = takeTime;
    }

    public Long getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(Long currentTime) {
        this.currentTime = currentTime;
    }
}
