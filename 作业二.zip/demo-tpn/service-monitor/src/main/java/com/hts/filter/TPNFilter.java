package com.hts.filter;

import com.hts.bean.MethodInfo;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Activate(group = {CommonConstants.CONSUMER})
public class TPNFilter implements Filter {

    Map<String, List<MethodInfo>> methodInfoMap = new ConcurrentHashMap<>();

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        Result result = null;
        Long takeTimes = 0L;
        String methodName = invocation.getMethodName();

        if (methodName.toLowerCase().equals("methodtest")) {
            // 消费端每隔5s会请求一次统计
            for (Map.Entry<String, List<MethodInfo>> stringListEntry : methodInfoMap.entrySet()) {
                String key = stringListEntry.getKey();
                List<MethodInfo> value = stringListEntry.getValue();
                if (key.equals("methodTest")) {
                    continue;
                }

                long tp90 = getTP(value, 0.9);
                long tp99 = getTP(value, 0.99);
                System.out.println("方法：" + key + "。TP90是：" + tp90);
                System.out.println("方法：" + key + "。TP99是：" + tp99);
            }
            System.out.println("===========统计结束，等待下一个5秒==============");
            // 统计完清空
            methodInfoMap.clear();
        }

        try {
            long startTime = System.currentTimeMillis();
            result = invoker.invoke(invocation);

            if (result.getException() instanceof Exception) {
                throw new Exception(result.getException());
            }

            takeTimes = System.currentTimeMillis() - startTime;
        } catch (Exception ex) {
            ex.printStackTrace();
            return result;
        }


        List<MethodInfo> methodInfos = methodInfoMap.get(methodName);
        if (CollectionUtils.isEmpty(methodInfos)) {
            methodInfos = new ArrayList<>();
            methodInfoMap.put(methodName, methodInfos);
        }

        methodInfos.add(new MethodInfo(invocation.getMethodName(), takeTimes, System.currentTimeMillis()));

        return result;
    }

    private long getTP(List<MethodInfo> methodInfos, double rate) {
        List<MethodInfo> sortInfo = new ArrayList<>();

        long endTime = System.currentTimeMillis();
        long startTime = System.currentTimeMillis() - 60000;
        int size = methodInfos.size();
        for (int i = 0; i < size; i++) {
            MethodInfo methodInfo = methodInfos.get(i);
            if (methodInfo.getCurrentTime() >= startTime && methodInfo.getCurrentTime() <= endTime) {
                sortInfo.add(methodInfo);
            }
        }

        sortInfo.sort(new Comparator<MethodInfo>() {
            @Override
            public int compare(MethodInfo o1, MethodInfo o2) {
                if (o1.getTakeTime() > o2.getTakeTime()) {
                    return 1;
                } else if (o1.getTakeTime() < o2.getTakeTime()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });

        int index = (int) (sortInfo.size() * rate);

        return sortInfo.get(index).getTakeTime();
    }
}
