package com.hts.service.provider.service.impl;

import com.hts.service.api.service.HelloService;
import org.apache.dubbo.config.annotation.Service;

import java.util.Random;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Service
public class HelloServiceImpl implements HelloService {


    @Override
    public void methodA() {
        try {
            Thread.sleep((int) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("methodA");
    }

    @Override
    public void methodB() {
        try {
            Thread.sleep((int) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("methodB");
    }

    @Override
    public void methodC() {
        try {
            Thread.sleep((int) (Math.random() * 100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("methodC");
    }

    @Override
    public void methodTest() {
        try {
            System.out.println("统计");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
