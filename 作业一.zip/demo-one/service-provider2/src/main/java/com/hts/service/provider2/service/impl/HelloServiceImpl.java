package com.hts.service.provider2.service.impl;

import com.hts.service.api.service.HelloService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.rpc.RpcContext;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Service
public class HelloServiceImpl implements HelloService {
    @Override
    public String sayHello(String name) {
        String localHost = RpcContext.getContext().getLocalHost();
        System.out.println("Provider2 当前ip：" + localHost);
        return null;
    }
}
