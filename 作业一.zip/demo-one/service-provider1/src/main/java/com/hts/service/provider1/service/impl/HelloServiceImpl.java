package com.hts.service.provider1.service.impl;

import com.hts.service.api.service.HelloService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.rpc.RpcContext;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Service
public class HelloServiceImpl implements HelloService {
    @Override
    public String sayHello(String name) {
        String localHost = RpcContext.getContext().getLocalHost();
        System.out.println("Provider1 当前ip：" + localHost);
        return null;
    }
}
