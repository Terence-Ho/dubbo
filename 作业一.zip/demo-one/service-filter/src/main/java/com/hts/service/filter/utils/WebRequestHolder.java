package com.hts.service.filter.utils;

import javax.servlet.ServletRequest;

public class WebRequestHolder {

    private static ThreadLocal<ServletRequest> REQUEST_THREAD_LOCAL = new ThreadLocal<>();

    public static ServletRequest request() {
        return REQUEST_THREAD_LOCAL.get();
    }

    static void setting(ServletRequest request) {
        REQUEST_THREAD_LOCAL.set(request);
    }

    static void remove() {
        REQUEST_THREAD_LOCAL.remove();
    }
}
