package com.hts.service.filter.utils;

import org.apache.dubbo.rpc.RpcContext;

import javax.servlet.ServletRequest;
import java.util.Map;

public class DubboTraffic {

    public static final String REQUEST_IP = "request_ip";

    public static String getRequestIp() {
        final Map<String, String> attachments = RpcContext.getContext().getAttachments();
        return attachments.get(REQUEST_IP);
    }

    public static void saveFrom(ServletRequest request) {
        if (request == null) {
            return;
        }

        Map<String, String> attachments = RpcContext.getContext().getAttachments();

        attachments.put(REQUEST_IP, request.getRemoteAddr());
    }
}
