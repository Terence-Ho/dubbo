package com.hts.service.filter.utils;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

@Activate(group = {CommonConstants.CONSUMER})
public class TransportIpFilter implements Filter {
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        DubboTraffic.saveFrom(WebRequestHolder.request());
        return invoker.invoke(invocation);
    }
}
