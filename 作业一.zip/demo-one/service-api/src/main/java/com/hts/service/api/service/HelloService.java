package com.hts.service.api.service;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
public interface HelloService {

    String sayHello(String name);
}
