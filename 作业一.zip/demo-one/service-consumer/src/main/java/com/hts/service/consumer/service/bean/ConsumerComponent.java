package com.hts.service.consumer.service.bean;

import com.hts.service.provider1.service.impl.HelloServiceImpl;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Component;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
@Component
public class ConsumerComponent {

    @Reference
    private HelloServiceImpl helloServiceimpl1;

    @Reference
    private com.hts.service.provider2.service.impl.HelloServiceImpl helloServiceimpl2;

    public String helloService1Method() {
        return helloServiceimpl1.sayHello("hello world1");
    }

    public String helloService2Method() {
        return helloServiceimpl2.sayHello("hello world2");
    }



}
