package com.hts.service.consumer.service;

import com.hts.service.consumer.service.bean.ConsumerComponent;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author hetiansheng
 * @date 2020/5/10
 */
public class ConsumerApplication {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ProviderConfiguration.class);
        context.start();
        System.out.println("消费者 启动成功");
        ConsumerComponent service = context.getBean(ConsumerComponent.class);

        String s = service.helloService1Method();
        System.out.println("访问服务1结果：" + s);

        String s1 = service.helloService2Method();
        System.out.println("访问服务2结果：" + s1);

    }

    @Configuration
    @PropertySource("classpath:/dubbo-consumer.properties")
    @ComponentScan("com.hts.service.consumer.service")
    @EnableDubbo
    static class ProviderConfiguration {

    }
}
